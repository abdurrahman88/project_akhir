JQVMap.prototype.removePins = function(){
  this.container.find('.jqvmap-pin').remove();
};
