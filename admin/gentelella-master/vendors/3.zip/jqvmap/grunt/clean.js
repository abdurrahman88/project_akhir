module.exports = {
	dist: [
		"dist/*.js"
	]
};
