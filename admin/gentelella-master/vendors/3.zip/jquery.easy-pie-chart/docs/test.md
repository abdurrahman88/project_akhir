To run the test just use the karma adapter of grunt: `grunt test`
